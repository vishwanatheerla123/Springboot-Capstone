package com.example.demo;

import com.infy.demo1.EmployeeDTO;

public interface EmployeeService {
	void insert(EmployeeDTO emp);
}
