package com.infy.Entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import org.springframework.beans.factory.annotation.Autowired;

import com.infy.dto.TrainDTO;
import com.infy.repository.RouteRepository;


@Entity
public class Route {

	@Id
	@Column(name="route_id")
	private int id;
	private String source;
	private String destination;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name ="list_id", referencedColumnName="route_id")
	private List<Train> trainList;
	
	

	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public List<Train> getTrainList() {
		return trainList;
	}
	public void setTrainList(List<Train> trainList) {
		this.trainList = trainList;
	}
	
	public static List<Train> setTrainsByTrainDTOList(List<TrainDTO> tDTOList) {
		List<Train> tList=new ArrayList<>();
		for(TrainDTO tDTO:tDTOList) {
			Train t=TrainDTO.prepareTrainEntity(tDTO);
			tList.add(t);
		}
		return tList;
		
	}

}
