package com.infy.dto;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.infy.Entity.Route;
import com.infy.Entity.Train;

public class RouteDTO {
	
	@Max(value=999,message = "{route.id.invalid}")
	@Min(value=100,message = "{route.id.invalid}")
	private int id;
	@NotEmpty(message = "{route.source.empty}")
	@Pattern(regexp="^[A-Za-z]*$",message = "{route.source.invalid}")
	private String source;
	@NotEmpty(message = "{route.destination.empty}")
	@Pattern(regexp="^[A-Za-z]*$",message = "{route.destination.invalid}")
	private String destination;
	@NotEmpty(message = "{route.trainList.empty}")
	private List<TrainDTO> trainList;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public List<TrainDTO> getTrainList() {
		return trainList;
	}
	public void setTrainList(List<TrainDTO> trainList) {
		this.trainList = trainList;
	}
	
	
	public static List<TrainDTO> setTrainsByTrainDTOList(List<Train> tList) {
		List<TrainDTO> tDTOList=new ArrayList<>();
		for(Train t:tList) {
			TrainDTO tDTO=Train.prepareTrainDTO(t);
			tDTOList.add(tDTO);
		}
		return tDTOList;		
	}
	

}
